ARDUINO 1.8.12

Voreinstellungen =  " Strg+, "
Add: https://dl.espressif.com/dl/package_esp32_index.json






